from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pickle
import time

driver = webdriver.Chrome()
driver.get("https://www.facebook.com")
time.sleep(5)

with open("fb_cookies.pkl", "rb") as f:
    cookies = pickle.load(f)

for cookie in cookies:
    if 'expiry' in cookie:
        del cookie['expiry']
    driver.add_cookie(cookie)


driver.get("https://www.facebook.com")
time.sleep(5)

try:
    post_container = WebDriverWait(driver, 15).until(
        EC.presence_of_element_located((By.XPATH, "//span[contains(text(), \"What's on your mind\")]"))
    )
    post_container.click()
    time.sleep(3)

    text_area = WebDriverWait(driver, 15).until(
        EC.presence_of_element_located((By.XPATH, "//div[@role='textbox']"))
    )
    text_area.send_keys("LENOVO")

    time.sleep(2)

    post_button = WebDriverWait(driver, 15).until(
        EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post' or @aria-label='Share']"))
    )
    post_button.click()

    print("🎉 Successfully posted!")

except Exception as e:
    driver.save_screenshot("post_error.png") 
    print("❌ Failed to post:", e)

time.sleep(5)
driver.quit()

from selenium import webdriver
import pickle
import time

driver = webdriver.Chrome()
driver.get("https://www.facebook.com")

print("🔐 Please log in to Facebook manually within 60 seconds...")
time.sleep(60) 

cookies = driver.get_cookies()
with open("fb_cookies.pkl", "wb") as f:
    pickle.dump(cookies, f)

print("✅ Facebook login cookies saved successfully.")
driver.quit()
